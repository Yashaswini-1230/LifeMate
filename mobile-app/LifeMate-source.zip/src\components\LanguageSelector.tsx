
import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
} from "react-native";
import { Search, Check, ChevronDown } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { SUPPORTED_LANGUAGES } from "../i18n";
const PURPLE = "#8B70D9";
const DARK = "#25213A";
const MUTED = "#817B96";

export const LANGUAGES = [
  { code: "en", name: "English", native: "English" },
  { code: "te", name: "Telugu", native: "తెలుగు" },
  { code: "hi", name: "Hindi", native: "हिन्दी" },
  { code: "kn", name: "Kannada", native: "ಕನ್ನಡ" },
  { code: "ta", name: "Tamil", native: "தமிழ்" },
  { code: "mr", name: "Marathi", native: "मराठी" },
  { code: "ml", name: "Malayalam", native: "മലയാളം" },
  { code: "bn", name: "Bengali", native: "বাংলা" },
  { code: "gu", name: "Gujarati", native: "ગુજરાતી" },
  { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "or", name: "Odia", native: "ଓଡ଼ିଆ" },
  { code: "as", name: "Assamese", native: "অসমীয়া" },
  { code: "ur", name: "Urdu", native: "اردو" },
  { code: "sa", name: "Sanskrit", native: "संस्कृतम्" },
  { code: "fr", name: "French", native: "Français" },
  { code: "es", name: "Spanish", native: "Español" },
  { code: "de", name: "German", native: "Deutsch" },
  { code: "it", name: "Italian", native: "Italiano" },
  { code: "pt", name: "Portuguese", native: "Português" },
  { code: "ru", name: "Russian", native: "Русский" },
  { code: "ja", name: "Japanese", native: "日本語" },
  { code: "ko", name: "Korean", native: "한국어" },
  { code: "zh", name: "Chinese", native: "中文" },
  { code: "ar", name: "Arabic", native: "العربية" },
  { code: "tr", name: "Turkish", native: "Türkçe" },
  { code: "id", name: "Indonesian", native: "Bahasa Indonesia" },
  { code: "th", name: "Thai", native: "ไทย" },
  { code: "vi", name: "Vietnamese", native: "Tiếng Việt" },
  { code: "ne", name: "Nepali", native: "नेपाली" },
  { code: "si", name: "Sinhala", native: "සිංහල" },
  { code: "nl", name: "Dutch", native: "Nederlands" },
  { code: "ms", name: "Malay", native: "Bahasa Melayu" },
  { code: "fil", name: "Filipino", native: "Filipino" },
  { code: "fa", name: "Persian", native: "فارسی" },
  { code: "uk", name: "Ukrainian", native: "Українська" },
  { code: "el", name: "Greek", native: "Ελληνικά" },
  { code: "pl", name: "Polish", native: "Polski" },
  { code: "sv", name: "Swedish", native: "Svenska" },
  { code: "sw", name: "Swahili", native: "Kiswahili" },
  { code: "he", name: "Hebrew", native: "עברית" },
];

export function getLanguageName(value: string): string {
  const language = LANGUAGES.find(
    (item) =>
      item.code === value ||
      item.name === value ||
      item.native === value
  );
return language?.native ?? value;
  
}

type Props = {
  value: string;
  onChange: (language: string) => void;
};

export default function LanguageSelector({
  value,
  onChange,
}: Props) {
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState(false);

  const query = search.trim().toLowerCase();

  const filtered = LANGUAGES.filter(
    (item) =>
      item.name.toLowerCase().includes(query) ||
      item.native.toLowerCase().includes(query) ||
      item.code.toLowerCase() === query
  );

  const visibleLanguages =
    query || expanded
      ? filtered
      : LANGUAGES.filter(
          (item, index) =>
            index < 5 ||
            item.code === value ||
            item.name === value ||
            item.native === value
        );

  return (
    <View style={styles.container}>
      <View style={styles.searchBox}>
        <Search size={20} color={MUTED} />

        <TextInput
          style={styles.searchInput}
          placeholder="Search languages..."
          placeholderTextColor={MUTED}
          value={search}
          onChangeText={setSearch}
          autoCorrect={false}
          autoCapitalize="none"
        />

        {search.length > 0 && (
          <Pressable
            onPress={() => setSearch("")}
            accessibilityLabel="Clear search"
          >
            <Text style={styles.clear}>✕</Text>
          </Pressable>
        )}
      </View>

      <Text style={styles.heading}>
        {query
          ? "Search results"
          : expanded
            ? "All languages"
            : "Popular languages"}
      </Text>

      {visibleLanguages.map((item) => {
        const selected =
          value === item.code ||
          value === item.name ||
          value === item.native;

        return (
          <Pressable
            key={item.code}
            accessibilityRole="radio"
            accessibilityState={{ checked: selected }}
            style={[
              styles.option,
              selected && styles.selectedOption,
            ]}
            onPress={() => onChange(item.code)}
          >
            <View style={{ flex: 1 }}>
              <Text style={styles.nativeName}>
                {item.native}
              </Text>

              {item.native !== item.name && (
                <Text style={styles.englishName}>
                  {item.name}
                </Text>
              )}
            </View>

            <View
              style={[
                styles.radio,
                selected && styles.selectedRadio,
              ]}
            >
              {selected && (
                <Check size={14} color="#FFFFFF" />
              )}
            </View>
          </Pressable>
        );
      })}

      {visibleLanguages.length === 0 && (
        <View style={styles.empty}>
          <Text style={styles.emptyTitle}>
            No languages found
          </Text>

          <Text style={styles.hint}>
            Try searching using another language name.
          </Text>
        </View>
      )}

      {!query && (
        <Pressable
          style={styles.expandButton}
          onPress={() => setExpanded(!expanded)}
        >
          <Text style={styles.expandText}>
            {expanded
              ? "Show fewer languages"
              : `View all ${LANGUAGES.length} languages`}
          </Text>

          <ChevronDown
            size={18}
            color={PURPLE}
            style={{
              transform: [
                { rotate: expanded ? "180deg" : "0deg" },
              ],
            }}
          />
        </Pressable>
      )}

      <View style={styles.selection}>
        <Check size={17} color={PURPLE} />

        <Text style={styles.selectionText}>
          Selected: {getLanguageName(value)}
        </Text>
      </View>

      <Text style={styles.hint}>
        This saves your preferred language. Interface
        translations will be available as language support
        is added.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EAE4F3",
    borderRadius: 15,
    paddingHorizontal: 15,
    minHeight: 54,
  },
  searchInput: {
    flex: 1,
    color: DARK,
    fontSize: 14,
    paddingVertical: 12,
  },
  clear: {
    color: MUTED,
    fontSize: 16,
    padding: 5,
  },
  heading: {
    color: MUTED,
    fontSize: 12,
    fontWeight: "700",
    marginTop: 5,
  },
  option: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EAE4F3",
    borderRadius: 15,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  selectedOption: {
    backgroundColor: "#F0EAFE",
    borderColor: PURPLE,
  },
  nativeName: {
    fontSize: 16,
    fontWeight: "700",
    color: DARK,
  },
  englishName: {
    fontSize: 12,
    color: MUTED,
    marginTop: 4,
  },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1.5,
    borderColor: PURPLE,
    alignItems: "center",
    justifyContent: "center",
  },
  selectedRadio: {
    backgroundColor: PURPLE,
  },
  expandButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 12,
  },
  expandText: {
    color: PURPLE,
    fontSize: 14,
    fontWeight: "700",
  },
  selection: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#F0EAFE",
    borderRadius: 12,
    padding: 12,
  },
  selectionText: {
    flex: 1,
    color: DARK,
    fontWeight: "600",
    fontSize: 13,
  },
  hint: {
    fontSize: 12,
    color: MUTED,
    lineHeight: 19,
  },
  empty: {
    padding: 20,
    alignItems: "center",
    gap: 6,
  },
  emptyTitle: {
    fontSize: 15,
    color: DARK,
    fontWeight: "700",
  },
});

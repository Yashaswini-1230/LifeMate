import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";

import {
  Settings,
  LayoutGrid,
  Bell,
  ShieldCheck,
  CircleHelp,
  ChevronRight,
} from "lucide-react-native";

import ProfileAvatar from "../../components/ProfileAvatar";
import { useProfile } from "../../context/ProfileContext";
import { colors } from "../../theme/colors";

const menuItems = [
  {
    title: "Manage my features",
    description: "Choose the features you need",
    icon: LayoutGrid,
  },
  {
    title: "Preferences",
    description: "Language and daily routine",
    icon: Settings,
  },
  {
    title: "Notifications",
    description: "Manage reminders and sounds",
    icon: Bell,
  },
  {
    title: "Privacy & Security",
    description: "Manage your privacy preferences",
    icon: ShieldCheck,
  },
  {
    title: "Help & Support",
    description: "Learn how to use LifeMate",
    icon: CircleHelp,
  },
];

export default function MoreScreen() {
  const router = useRouter();
  const { profile, loading } = useProfile();

  return (
    <SafeAreaView
      style={styles.container}
      edges={["top", "left", "right"]}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        <Text style={styles.title}>More</Text>

        <Text style={styles.subtitle}>
          Make LifeMate work your way.
        </Text>

        {/* Profile card */}

        <Pressable
          accessibilityRole="button"
          accessibilityLabel="View and edit my profile"
          disabled={loading || !profile}
          onPress={() => router.push("/profile")}
          style={({ pressed }) => [
            styles.profileCard,
            pressed && styles.pressed,
          ]}
        >
          <ProfileAvatar
            name={profile?.name}
            size={58}
          />

          <View style={styles.profileDetails}>
            <Text style={styles.profileName}>
              {loading
                ? "Loading profile..."
                : profile?.name || "LifeMate User"}
            </Text>

            <Text
              style={styles.profileEmail}
              numberOfLines={1}
            >
              {profile?.email || ""}
            </Text>

            <Text style={styles.viewProfile}>
              View and edit profile
            </Text>
          </View>

          <ChevronRight
            size={22}
            color={colors.muted}
          />
        </Pressable>

        {/* Settings section */}

        <Text style={styles.sectionTitle}>
          Settings
        </Text>

        <View style={styles.menu}>
          {menuItems.map((item, index) => {
            const Icon = item.icon;

            return (
              <View
                key={item.title}
                style={[
                  styles.item,
                  index === menuItems.length - 1 &&
                    styles.lastItem,
                ]}
              >
                <View style={styles.iconBox}>
                  <Icon
                    size={22}
                    color={colors.primaryDark}
                  />
                </View>

                <View style={styles.details}>
                  <Text style={styles.itemTitle}>
                    {item.title}
                  </Text>

                  <Text style={styles.description}>
                    {item.description}
                  </Text>

                  <Text style={styles.comingSoon}>
                    Coming soon
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        <Text style={styles.footer}>
          Your LifeMate. Your way.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  content: {
    padding: 24,
    paddingBottom: 32,
    width: "100%",
    maxWidth: 600,
    alignSelf: "center",
  },

  title: {
    fontSize: 28,
    fontWeight: "800",
    color: colors.text,
  },

  subtitle: {
    fontSize: 14,
    color: colors.muted,
    marginTop: 8,
  },

  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 16,
    marginTop: 24,
    gap: 14,
  },

  profileDetails: {
    flex: 1,
    minWidth: 0,
    gap: 5,
  },

  profileName: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.text,
  },

  profileEmail: {
    fontSize: 12,
    color: colors.muted,
  },

  viewProfile: {
    fontSize: 12,
    fontWeight: "600",
    color: colors.primaryDark,
    marginTop: 3,
  },

  pressed: {
    opacity: 0.75,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
    marginTop: 28,
    marginBottom: 12,
  },

  menu: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },

  item: {
    flexDirection: "row",
    alignItems: "center",
    padding: 15,
    gap: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  lastItem: {
    borderBottomWidth: 0,
  },

  iconBox: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },

  details: {
    flex: 1,
    gap: 4,
  },

  itemTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
  },

  description: {
    fontSize: 12,
    color: colors.muted,
    lineHeight: 18,
  },

  comingSoon: {
    fontSize: 11,
    color: colors.primaryDark,
    marginTop: 2,
  },

  footer: {
    color: colors.muted,
    textAlign: "center",
    fontSize: 12,
    marginTop: 28,
  },
});